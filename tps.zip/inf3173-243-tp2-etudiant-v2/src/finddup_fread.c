#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>

#include "crc32.h"
#include "finddup_fread.h"
#include "finddup_main.h"
#include "hashmap.h"
#include "list.h"

// Function to calculate checksum with block processing
int finddup_fread(struct list* files, struct hashmap* hmap, int block_size) {
  int ok = 0;
  struct list_node* node = list_head(files);

  while (!list_end(node)) {
    const char* fname = node->data;
    FILE* f = fopen(fname, "rb");
    if (!f) {
      perror("Error opening file");
      return -1;
    }

    uint32_t hash = 0;  // Initialize hash for this file
    char* buffer = malloc(block_size);
    if (!buffer) {
      perror("Memory allocation failed");
      fclose(f);
      return -1;
    }

    fseek(f, 0, SEEK_END);
    size_t file_size = ftell(f);
    fseek(f, 0, SEEK_SET);

    size_t bytes_read;
    int fread_count = 0;
    size_t total_bytes_to_read = file_size;

    while (total_bytes_to_read > 0) {
      size_t bytes_to_read = (total_bytes_to_read < block_size) ? total_bytes_to_read : block_size;
      bytes_read = fread(buffer, 1, bytes_to_read, f);

      if (bytes_read > 0) {
        hash = crc32(hash, (char*)buffer, bytes_read);
        fread_count++;
        total_bytes_to_read -= bytes_read;

      } else if (ferror(f)) {
        perror("File read error");
        fclose(f);
        free(buffer);
        return -1;
      }
    }

    filegroup_add(hmap, hash, fname);
    ok++;

    fclose(f);
    free(buffer);
    node = node->next;
  }

  return (list_size(files) == ok) ? 0 : -1;
}
