// #include "finddup_mmap.h"

// #include "crc32.h"
// #include "finddup_main.h"

// int finddup_mmap(struct list* files, struct hashmap* hmap, int block_size) {
//   // TODO : À COMPLÉTER
//   // Astuce: prendre le contenu de finddup_simple() et adapter
//   return -1;
// }

#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <unistd.h>

#include "crc32.h"
#include "hashmap.h"
#include "list.h"

int finddup_mmap(struct list* files, struct hashmap* hmap, int block_size) {
  int ok = 0;
  struct list_node* node = list_head(files);

  while (!list_end(node)) {
    const char* fname = node->data;
    int fd = open(fname, O_RDONLY);
    if (fd < 0) {
      perror("Error opening file");
      return -1;
    }

    struct stat st;
    if (fstat(fd, &st) < 0) {
      perror("Error getting file size");
      close(fd);
      return -1;
    }
    size_t file_size = st.st_size;

    void* file_map = mmap(NULL, file_size, PROT_READ, MAP_SHARED, fd, 0);
    if (file_map == MAP_FAILED) {
      perror("Error mapping file");
      close(fd);
      return -1;
    }

    unsigned long crc = 0;
    unsigned char* data = (unsigned char*)file_map;
    int mmap_count = 0;

    for (size_t offset = 0; offset < file_size; offset += block_size) {
      size_t chunk_size = (file_size - offset < block_size) ? (file_size - offset) : block_size;
      crc = crc32(crc, data + offset, chunk_size);
      mmap_count++;

    }

    filegroup_add(hmap, crc, fname);
    ok++;

    munmap(file_map, file_size);
    close(fd);
    node = node->next;
  }

  return (list_size(files) == ok) ? 0 : -1;
}
