#include "crc32.h"
#include "finddup_main.h"
#include "finddup_read.h"

// int finddup_read(struct list* files, struct hashmap* hmap, int block_size) {
//   // TODO : À COMPLÉTER
//   // Astuce: prendre le contenu de finddup_simple() et adapter
//   return -1;
// }

#include <fcntl.h>
#include <stdio.h>

int finddup_read(struct list* files, struct hashmap* hmap, int block_size) {
  int ok = 0;
  struct list_node* node = list_head(files);

  while (!list_end(node)) {
    const char* fname = node->data;
    int fd = open(fname, O_RDONLY);
    if (fd < 0) {
      perror("Error opening file");
      return -1;
    }

    uint32_t hash = 0;
    char* buffer = malloc(block_size);
    if (!buffer) {
      perror("Memory allocation failed");
      close(fd);
      return -1;
    }

    struct stat st;
    if (fstat(fd, &st) != 0) {
      perror("Error getting file size");
      close(fd);
      free(buffer);
      return -1;
    }
    size_t file_size = st.st_size;
    size_t total_bytes_to_read = file_size;
    ssize_t bytes_read;
    int read_count = 0;

    while (total_bytes_to_read > 0) {
      size_t bytes_to_read = (total_bytes_to_read < block_size) ? total_bytes_to_read : block_size;

      bytes_read = read(fd, buffer, bytes_to_read);

      if (bytes_read < 0) {
        perror("File read error");
        close(fd);
        free(buffer);
        return -1;
      }
      if (bytes_read == 0) {
        break;  // End of file
      }

      hash = crc32(hash, (unsigned char*)buffer, bytes_read);
      read_count++;
      total_bytes_to_read -= bytes_read;

    }

    filegroup_add(hmap, hash, fname);
    ok++;

    close(fd);
    free(buffer);
    node = node->next;
  }

  return (list_size(files) == ok) ? 0 : -1;
}
