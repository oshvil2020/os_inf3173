#pragma once

void foo();
