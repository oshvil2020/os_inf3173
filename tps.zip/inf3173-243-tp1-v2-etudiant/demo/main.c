#include <stdio.h>

#include "foo.h"
#include "bar.h"

int main()
{
    printf("Hola!\n");
    bar();
    return 0;
}	
