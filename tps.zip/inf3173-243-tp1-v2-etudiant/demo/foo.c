#include "foo.h"
#include <stdio.h>

void foo() {
    printf("foo\n");
}
