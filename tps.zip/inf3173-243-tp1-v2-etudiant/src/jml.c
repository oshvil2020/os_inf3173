#include <cwalk.h>
#include <dirent.h>
#include <getopt.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <sys/wait.h>
#include <unistd.h>

#include "jml.h"
#include "utils.h"

// Cette fonction remplace l'extension d'un fichier et le déplace vers le
// répertoire de construction.
void replace_extension(struct jml_app* app, char* filename, const char* new_ext) {
  char temp[PATH_MAX];

  char* dot = strrchr(filename, '.');
  if (dot && strcmp(dot, ".c") == 0) {
    strlcpy(dot, new_ext, PATH_MAX);
  }

  const char* base = strrchr(filename, '/');
  if (!base) {
    base = filename;
  } else {
    base++;
  }
  strlcpy(temp, app->builddir, PATH_MAX);
  strlcat(temp, "/", PATH_MAX);
  strlcat(temp, base, PATH_MAX);
  strlcpy(filename, temp, PATH_MAX);
}

int init_build_dir(const char* builddir) {
  struct stat st = {0};
  if (stat(builddir, &st) == -1) {
    if (mkdir(builddir, 0755) == -1) {
      perror("Échec de la création du répertoire");
      return 1;
    }
  }
  return 0;
}

int compile_sources(struct jml_app* app, struct list* files) {
  struct list* compile_commands = list_new(NULL, jml_command_free);
  if (!compile_commands) {
    perror("Échec de l'initialisation de la liste des commandes de compilation");
    return -1;
  }

  struct list_node* node = list_head(files);
  int i = 0;
  while (!list_end(node)) {
    char* filename = (char*)list_index(files, i)->data;
    char filename_o[PATH_MAX];
    strlcpy(filename_o, filename, sizeof(filename_o));

    struct command* cmd = malloc(sizeof(struct command));
    if (!cmd) {
      perror("Échec de l'allocation mémoire (malloc)");
      list_free(compile_commands);
      return -1;
    }
    jml_command_init(cmd);
    jml_command_append(cmd, "gcc");
    jml_command_append(cmd, "-o");
    replace_extension(app, filename_o, ".o");
    jml_command_append(cmd, filename_o);
    jml_command_append(cmd, "-c");
    jml_command_append(cmd, filename);

    if (app->cflags != NULL) {
      jml_command_append_many(cmd, app->cflags, " ");
    }
    struct list_node* cmd_node = list_node_new(cmd);
    if (!cmd_node) {
      perror("Erreur lors de la création d'un nœud de liste pour la commande");
      jml_command_destroy(cmd);
      list_free(compile_commands);
      return -1;
    }
    list_push_back(compile_commands, cmd_node);
    node = node->next;
    i++;
  }

  int ret = jml_command_exec_all(compile_commands, app->nproc, app->keep_going);
  if (ret != 0) {
    perror("Erreur lors de la compilation des fichiers source");
  }
  list_free(compile_commands);
  return ret;
}

int link_objects(struct jml_app* app, struct list* files) {
  struct command link_cmd;
  jml_command_init(&link_cmd);
  jml_command_append(&link_cmd, "gcc");
  jml_command_append(&link_cmd, "-o");

  char tmp[PATH_MAX];
  snprintf(tmp, PATH_MAX, "%s/%s", app->builddir, app->progname);
  jml_command_append(&link_cmd, tmp);

  for (int i = 0; i < files->size; i++) {
    char* file_o = (char*)list_index(files, i)->data;
    jml_command_append(&link_cmd, file_o);
  }
  if (app->libs) {
    jml_command_append_many(&link_cmd, app->libs, " ");
  }

  int ret = jml_command_exec_one(&link_cmd);
  if (ret != 0) {
    perror("Erreur lors de l'exécution de la liaison des fichiers objets");
  }
  jml_command_destroy(&link_cmd);
  return ret;
}

int jml_main(struct jml_app* app) {
  if (app->sourcedir == NULL) {
    perror("Error: Source directory (-s) must be specified.\n");
    return 1;
  }

  int ret = init_build_dir(app->builddir);
  if (ret != 0) {
    return ret;
  }

  struct list* files = list_new(NULL, free);
  if (!files) {
    perror("Échec de l'initialisation de la liste des fichiers");
    return -1;
  }

  ret = jml_listdir(files, app->sourcedir, ".c");
  if (ret != 0) {
    perror("Erreur lors de la liste des fichiers source");
    list_free(files);
    return ret;
  }

  ret = compile_sources(app, files);
  list_free(files);
  if (ret != 0) {
    return ret;
  }

  files = list_new(NULL, free);
  ret = jml_listdir(files, app->builddir, ".o");
  if (ret != 0) {
    perror("Erreur lors de la liste des fichiers objets");
    list_free(files);
    return ret;
  }

  ret = link_objects(app, files);
  list_free(files);

  return ret;
}

// Fonction pour vérifier si le fichier a l'extension spécifiée
int has_extension(const char* filename, const char* ext) {
  const char* dot = strrchr(filename, '.');
  return dot && strcmp(dot, ext) == 0;
}

// Lister les fichiers ayant l'extension ext du répertoire dirname.
int jml_listdir(struct list* files, const char* dirname, const char* ext) {
  if (!dirname) {
    return -1;
  }

  DIR* dir = opendir(dirname);
  if (!dir) {
    perror("Erreur d'ouverture du répertoire");
    return -1;
  }

  struct dirent* entry;
  while ((entry = readdir(dir)) != NULL) {
    if (entry->d_type == DT_REG && has_extension(entry->d_name, ext)) {
      size_t dirname_len = strlen(dirname);
      size_t entry_len = strlen(entry->d_name);
      size_t filepath_len = dirname_len + entry_len + 2;

      char* filepath = malloc(filepath_len);
      if (!filepath) {
        perror("Error allocating memory for file path");
        closedir(dir);
        return -1;
      }

      strlcpy(filepath, dirname, PATH_MAX);
      filepath[dirname_len] = '/';
      strlcpy(filepath + dirname_len + 1, entry->d_name, PATH_MAX);

      struct list_node* file_node = list_node_new(filepath);
      if (!file_node) {
        free(filepath);
        perror("Error creating list node");
        closedir(dir);
        return -1;
      }

      if (!list_push_back(files, file_node)) {
        free(filepath);
        free(file_node);
        perror("Error adding file node to list");
        closedir(dir);
        return -1;
      }
    }
  }
  closedir(dir);
  return 0;
}

// Exécuter une seule commande
int jml_command_exec_one(struct command* cmd) {
  if (cmd == NULL || cmd->args == NULL) {
    return -1;
  }
  pid_t pid = fork();
  if (pid == 0) {
    execvp(cmd->args[0], cmd->args);
    perror("execvp failed");
    exit(EXIT_FAILURE);
  } else if (pid > 0) {
    int status;
    waitpid(pid, &status, 0);

    if (WIFEXITED(status)) {
      int exit_status = WEXITSTATUS(status);
      if (exit_status != 0) {
        return -1;
      }
      return exit_status;
    } else {
      return -1;
    }
  } else {
    perror("fork failed");
    return -1;
  }

  return 0;
}

// Exécuter la liste de commandes avec max_process simultanément
int jml_command_exec_all(struct list* commands, int max_process, int keep_going) {
  if (!commands || commands->size == 0) {
    return -1;
  }

  int active_procs = 0;
  struct list_node* node = list_head(commands);
  int val_ret = 0;

  while (!list_end(node)) {
    struct command* cmd = (struct command*)node->data;

    while (active_procs >= max_process) {
      int status;
      pid_t finished_pid = wait(&status);
      if (finished_pid > 0) {
        active_procs--;

        if (WIFEXITED(status) && WEXITSTATUS(status) != 0) {
          val_ret = -1;
          if (!keep_going) {
            while (active_procs > 0) {
              wait(NULL);
              active_procs--;
            }
            return -1;
          }
        }
      }
    }

    pid_t pid = fork();
    if (pid == 0) {
      execvp(cmd->args[0], cmd->args);
      perror("execvp failed");
      exit(EXIT_FAILURE);
    } else if (pid > 0) {
      active_procs++;
    } else {
      perror("fork failed");
      return -1;
    }
    node = node->next;
  }

  while (active_procs > 0) {
    int status;
    wait(&status);
    active_procs--;

    if (WIFEXITED(status) && WEXITSTATUS(status) != 0) {
      val_ret = -1;
    }
  }

  return val_ret;
}

// Fonctions fournies pour aider à la création d'une commande.
void jml_command_init(struct command* c) {
  c->capacity = 1;
  c->args = calloc(c->capacity, sizeof(char*));
  c->nargs = 0;
}

void jml_command_append(struct command* c, const char* arg) {
  if (c->capacity == c->nargs + 1) {
    c->capacity *= 2;
    c->args = realloc(c->args, sizeof(char*) * c->capacity);
  }
  c->args[c->nargs++] = strdup(arg);
  c->args[c->nargs] = NULL;
}

void jml_command_destroy(struct command* c) {
  for (int i = 0; i < c->nargs; i++) {
    free(c->args[i]);
  }
  free(c->args);
  c->capacity = 0;
}

void jml_command_print(struct command* c, FILE* out) {
  for (int i = 0; i < c->nargs; i++) {
    fprintf(out, "%s ", c->args[i]);
  }
  fprintf(out, "\n");
}

void jml_command_free(void* cmd) {
  jml_command_destroy(cmd);
  free(cmd);
}

void jml_command_append_many(struct command* c, const char* arg, const char* delim) {
  struct list* tmp = list_new(NULL, free);
  split_string(tmp, arg, delim, 0);

  struct list_node* node = list_head(tmp);
  while (!list_end(node)) {
    jml_command_append(c, node->data);
    node = node->next;
  }

  list_free(tmp);
}
